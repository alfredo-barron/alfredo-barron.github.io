rm -rf ../proyectos/nebula/build/*
