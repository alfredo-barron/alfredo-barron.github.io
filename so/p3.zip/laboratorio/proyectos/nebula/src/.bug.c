BUG: Error inesperado
